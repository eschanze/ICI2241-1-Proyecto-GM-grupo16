package puppy.code;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;

public class Lluvia {
    // Variables patrón de ataque
    private Array<Proyectil> proyectiles;
    private Array<PatronAtaque> patrones;
    private PatronAtaque patronActual;
    private int indicePatron;
    // Variables de gotas de lluvia
    private Texture gotaBuena;
    private Texture gotaMala;
    private Sound dropSound;
    private Music rainMusic;
    
    public Lluvia(Texture gotaBuena, Texture gotaMala, Sound ss, Music mm) {
        rainMusic = mm;
        dropSound = ss;
        this.gotaBuena = gotaBuena;
        this.gotaMala = gotaMala;
    }
    
    public void crear() {
        proyectiles = new Array<Proyectil>();
        patrones = new Array<PatronAtaque>();

        // Por ahora, solo se generan gotas de lluvia con un patrón circular
        patrones.add(new PatronCircular(400, 400, 32, 150, 5f, 0.5f, 30f, gotaBuena));
        // Iniciar el primer patrón
        indicePatron = 0;
        patronActual = patrones.get(indicePatron);
        patronActual.iniciar();

		// Empezar la reproducción de la música de fondo inmediatamente
        rainMusic.setLooping(true);
        rainMusic.play();
    }
    
    public boolean actualizarMovimiento(Tarro tarro) {
        float delta = com.badlogic.gdx.Gdx.graphics.getDeltaTime();
        
        // Actualizar patrón actual
        patronActual.actualizar(delta, proyectiles);
        
        // Si el patrón actual ha terminado, pasar al siguiente
        if (patronActual.estaCompleto()) {
            patronActual.limpiar();
            indicePatron = (indicePatron + 1) % patrones.size;
            patronActual = patrones.get(indicePatron);
            patronActual.iniciar();
        }
        
        // Actualizar proyectiles y verificar colisiones con el tarro
        for (int i = proyectiles.size - 1; i >= 0; i--) {
            Proyectil p = proyectiles.get(i);
            p.actualizar(delta);
            
            // Remover si está fuera de pantalla
            if (p.fueraDePantalla()) {
                proyectiles.removeIndex(i);
                continue;
            }
            
            // Verificar colisión con el tarro (Tarro.getHitbox())
            if (p.area.overlaps(tarro.getHitbox())) {
                if (p.tipo == 1) { // Dañina
                    tarro.dañar();
                    if (tarro.getVidas() <= 0)
                        return false;
                    proyectiles.removeIndex(i);
                } else { // Buena
                    tarro.sumarPuntos(10);
                    dropSound.play();
                    proyectiles.removeIndex(i);
                }
            }
        }
        
        return true;
    }
    
    public void actualizarDibujoLluvia(SpriteBatch batch) {
        patronActual.dibujar(batch, proyectiles);
    }
    
    public void destruir() {
        dropSound.dispose();
        rainMusic.dispose();
    }
    
    public void pausar() {
        rainMusic.stop();
    }
    
    public void continuar() {
        rainMusic.play();
    }
}