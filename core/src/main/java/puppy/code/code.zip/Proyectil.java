package puppy.code;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

public class Proyectil {
    public Rectangle area;
    public float velocidadX;
    public float velocidadY;
    public int tipo; // 1 = dañino, 2 = bueno
    public Texture textura;
    
    // Constructor
    public Proyectil(float x, float y, float vx, float vy, int tipo, Texture tex) {
        area = new Rectangle(x, y, 16, 16); // Tamaño del proyectil
        velocidadX = vx;
        velocidadY = vy;
        this.tipo = tipo;
        textura = tex;
    }
    
    // Actualizar la posición del proyectil
    public void actualizar(float delta) {
        area.x += velocidadX * delta;
        area.y += velocidadY * delta;
    }
    
    // Verificar si el proyectil está fuera de la pantalla
    public boolean fueraDePantalla() {
        return area.x < -32 || area.x > 832 || area.y < -32 || area.y > 512;
    }
}